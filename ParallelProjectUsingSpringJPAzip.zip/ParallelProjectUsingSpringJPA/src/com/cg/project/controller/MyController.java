package com.cg.project.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.project.dto.Customer;
import com.cg.project.dto.Transactions;
import com.cg.project.service.IBankService;


@Controller
public class MyController{

	@Autowired
	IBankService bankservice;
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll() {
		return "home";
	}
	
	@RequestMapping(value="create", method=RequestMethod.GET)
	public String createaccount(@ModelAttribute("my") Customer customer) {
		System.out.println("in create account");
		 return "createacc";
	}
	
	@RequestMapping(value="insertaccount", method=RequestMethod.POST)
	public String insertData(@ModelAttribute("my") Customer customer) 
	{
		String id = bankservice.createAccount(customer);
		return "addsuccess";
	}
	
	@RequestMapping(value="withdraw", method=RequestMethod.GET)
	public String withdrawamt(@ModelAttribute("my") Customer customer) {
		System.out.println("in withdraw account");
		 return "withdraw";
	}
	
	
	@RequestMapping(value="withdrawamt", method=RequestMethod.GET)
	public ModelAndView withdrawamount(@ModelAttribute("my") @RequestParam("amount") double amount, String mobNo, Map<String, Object> model) {
		double amt=bankservice.withdraw(mobNo, amount);
		return new ModelAndView("withdrawsuccess","withdrawamount", amt);
	}
	
	@RequestMapping(value="deposit", method=RequestMethod.GET)
	public String depositamt(@ModelAttribute("my") Customer customer) {
		System.out.println("in deposit account");
		 return "deposit";
	}
	
	@RequestMapping(value="depositamt", method=RequestMethod.POST)
	public ModelAndView depositamount(@ModelAttribute("my") @RequestParam("amount") double amount, String mobNo, Map<String, Object> model) {
		double amt=bankservice.deposit(mobNo, amount);
		return new ModelAndView("depositsuccess","depositamount", amt);
	}
	
	@RequestMapping(value="checkbal", method=RequestMethod.GET)
	public String checkbalance(@ModelAttribute("my") Customer customer) {
		 return "checkBal";
	}
	
	@RequestMapping(value="Balance", method=RequestMethod.POST)
	public ModelAndView balanceamount(@ModelAttribute("my") @RequestParam("mobNo") String mobNo, Map<String, Object> model) {
		double amt=bankservice.checkBalance(mobNo);
		return new ModelAndView("showbalance","balamount", amt);
	}
	
	@RequestMapping(value="fundTrans", method=RequestMethod.GET)
	public String transferfunds(@ModelAttribute("my") Customer customer) {
		 return "transferform";
	}
	
	@RequestMapping(value="fundtransfer", method=RequestMethod.POST)
	public ModelAndView transferamount(@ModelAttribute("my") @RequestParam("mobNo") String mobNo, @RequestParam("mobNo2") String mobNo2, @RequestParam("amount") double amount, Map<String, Object> model) {
		double amt=bankservice.fundTransfer(mobNo, mobNo2, amount);
		return new ModelAndView("transfersucc","newamount", amt);
	}
	
	@RequestMapping(value="printTrans", method=RequestMethod.GET)
	public String printtransac(@ModelAttribute("my") Customer customer) {
		 return "printTransaction";
	}
	
	@RequestMapping(value="printtansac", method=RequestMethod.POST)
	public ModelAndView transactionprint(@ModelAttribute("my") @RequestParam("mobNo") String mobNo, Map<String, Object> model) {
		List<Transactions> list=bankservice.getTransList(mobNo);
		return new ModelAndView("transactionpage","list", list);
	}
	
}
