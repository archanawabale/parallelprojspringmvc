package com.cg.project.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.project.dto.Customer;
import com.cg.project.dto.Transactions;

@Repository("bankDao")
public class BankDaoImpl implements IBankDao {

	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	
	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public String createAccount(Customer customer) {
		// TODO Auto-generated method stub
		entitymanager.persist(customer);
		entitymanager.flush();
		Transactions t1= new Transactions();
		t1.setMobNo(customer.getMobNo());
		t1.setAmount(0);
		t1.setCredDeb("credit");
		t1.setBalance(customer.getInitialBal());
		Date date = new Date();
		t1.setDate(String.valueOf(dateFormat.format(date)));
		entitymanager.persist(t1);
		return customer.getMobNo();
	}

	@Override
	public double deposit(String mobNo, double amount) {
		// TODO Auto-generated method stub
		Customer cust = entitymanager.find(Customer.class, mobNo);
		double newAmt =cust.getInitialBal();
		newAmt+=amount;
		cust.setInitialBal(newAmt);
		entitymanager.flush();
		passbookDeposit(cust,amount);
		return newAmt;
		
			
	}

	@Override
	public double withdraw(String mobNo, double amount) {
		// TODO Auto-generated method stub
		Customer cust = entitymanager.find(Customer.class, mobNo);
		double newAmt =cust.getInitialBal();
		newAmt=newAmt-amount;
		cust.setInitialBal(newAmt);
		entitymanager.flush();
		passbookWithdraw(cust, amount);
		return newAmt;
			
	}

	@Override
	public double checkBalance(String mobileNo) {
		// TODO Auto-generated method stub
		Customer cust = entitymanager.find(Customer.class, mobileNo);
		double newAmt =cust.getInitialBal();
		return newAmt;
	}

	@Override
	public double fundTransfer(String sender, String reciever, double amount) {
		// TODO Auto-generated method stub
		Customer cust1 = entitymanager.find(Customer.class, sender);
		double newAmt1 =cust1.getInitialBal();
		Customer cust2 = entitymanager.find(Customer.class, reciever);
		double newAmt2 =cust2.getInitialBal();
		newAmt1=newAmt1-amount;
		newAmt2=newAmt2+amount;
		cust1.setInitialBal(newAmt1);
		cust2.setInitialBal(newAmt2);
		entitymanager.flush();
		passbookFundTrans(cust1, cust2, amount);
		return newAmt1;
	}

	@Override
	public void passbookDeposit(Customer customer, double newAmt1) {
		Transactions t2= new Transactions();
		t2.setMobNo(customer.getMobNo());
		t2.setBalance(customer.getInitialBal());
		t2.setAmount(newAmt1);
		Date date = new Date();
		t2.setDate(String.valueOf(dateFormat.format(date)));
		t2.setCredDeb("credit");
		entitymanager.persist(t2);
	}
	
	@Override
	public void passbookWithdraw(Customer customer, double newAmt) {
		Transactions t3= new Transactions();
		t3.setMobNo(customer.getMobNo());
		t3.setBalance(customer.getInitialBal());
		t3.setAmount(newAmt);
		Date date = new Date();
		t3.setDate(String.valueOf(dateFormat.format(date)));
		t3.setCredDeb("debit");
		entitymanager.persist(t3);
	}
	
	@Override
	public void passbookFundTrans(Customer cust1, Customer cust2, double amt) {
		Transactions t4= new Transactions();
		Transactions t5= new Transactions();
		t4.setMobNo(cust1.getMobNo());
		t4.setBalance(cust1.getInitialBal());
		t4.setAmount(amt);
		Date date = new Date();
		t4.setDate(String.valueOf(dateFormat.format(date)));
		t4.setCredDeb("debit");
		entitymanager.persist(t4);
		t5.setMobNo(cust2.getMobNo());
		t5.setBalance(cust2.getInitialBal());
		t5.setAmount(amt);
		t5.setDate(String.valueOf(dateFormat.format(date)));
		t5.setCredDeb("credit");
		entitymanager.persist(t5);		
				
	}

	@Override
	public List<Transactions> getTransList(String mobNo) {
		// TODO Auto-generated method stub
		String qr = "select trans from Transactions trans where mobileNo ="+mobNo;
		TypedQuery<Transactions> query = entitymanager.createQuery(qr, Transactions.class);
		List<Transactions> list = query.getResultList();
		return list;
	}

}
