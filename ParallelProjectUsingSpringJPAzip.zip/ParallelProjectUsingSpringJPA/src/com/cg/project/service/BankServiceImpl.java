package com.cg.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.project.dao.IBankDao;
import com.cg.project.dto.Customer;
import com.cg.project.dto.Transactions;

@Service("bankservice")
@Transactional
public class BankServiceImpl implements IBankService {

	@Autowired
	IBankDao bankDao;
	
	@Override
	public String createAccount(Customer customer) {
		// TODO Auto-generated method stub
		return bankDao.createAccount(customer);
	}

	@Override
	public double deposit(String mobNo, double amount) {
		// TODO Auto-generated method stub
		return bankDao.deposit(mobNo, amount);
	}

	@Override
	public double withdraw(String mobNo, double amount) {
		// TODO Auto-generated method stub
		 return bankDao.withdraw(mobNo, amount);
	}

	@Override
	public double checkBalance(String mobileNo) {
		// TODO Auto-generated method stub
		return bankDao.checkBalance(mobileNo);
	}

	@Override
	public double fundTransfer(String sender, String reciever, double amount) {
		// TODO Auto-generated method stub
		return bankDao.fundTransfer(sender, reciever, amount);
	}

	@Override
	public List<Transactions> getTransList(String mobNo) {
		// TODO Auto-generated method stub
		return bankDao.getTransList(mobNo);
	}

	@Override
	public void passbookDeposit(Customer customer, double newAmt1) {
		// TODO Auto-generated method stub
		bankDao.passbookDeposit(customer, newAmt1);
	}

	@Override
	public void passbookWithdraw(Customer customer, double newAmt) {
		// TODO Auto-generated method stub
		bankDao.passbookWithdraw(customer, newAmt);
	}

	@Override
	public void passbookFundTrans(Customer cust1, Customer cust2, double amt) {
		// TODO Auto-generated method stub
		bankDao.passbookFundTrans(cust1, cust2, amt);
	}

	
}
