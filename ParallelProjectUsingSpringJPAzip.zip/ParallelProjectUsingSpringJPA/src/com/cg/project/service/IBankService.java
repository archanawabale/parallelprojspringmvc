package com.cg.project.service;

import java.util.List;

import com.cg.project.dto.Customer;
import com.cg.project.dto.Transactions;

public interface IBankService {

	public String createAccount(Customer customer);
	public double deposit(String mobNo, double amount);
	public double withdraw(String mobNo, double amount);
	public double checkBalance(String mobileNo);
	public double fundTransfer(String sender, String reciever, double amount);
	public List<Transactions> getTransList(String mobNo);
	public void passbookDeposit(Customer customer, double newAmt1);
	public void passbookWithdraw(Customer customer, double newAmt);
	public void passbookFundTrans(Customer cust1, Customer cust2, double amt);
}
